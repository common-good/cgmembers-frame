Gherkin for PHP & JS
====================

Gherkin language compiler for PHP (compiles into PHP) originally for use with Drupal

Also works with Javascript (compiles into Jasmine / Karma)

This set of programs is part of the rCredits system and is covered by that system's copyright.